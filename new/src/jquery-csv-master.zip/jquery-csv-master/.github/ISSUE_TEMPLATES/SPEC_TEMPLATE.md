# the name of the specification

A brief description of the specification

## Goals

- goal
- goal

## Milestones

- [ ] milestone
- [ ] milestone

## Details

Add code snippets and/or a more in-depth description of the implementation details

## References

 - [name](href)

*Note: If you're confused and need help getting started, ask lots of questions in the comments. Your contributions are appreciated and your effort is welcome, even if that requires discussing development practices that fall outside the scope of this project.*
